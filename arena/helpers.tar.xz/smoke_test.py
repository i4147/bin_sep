"""Functional smoke tests for the newest consolidated tools.

Builds tiny fixtures in a temp dir, runs real subcommands, checks
observable outcomes. Network test (pypi) is report-only.
"""
from __future__ import annotations

import json
import pickle
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path("/home/user/bin_sep")
PY = sys.executable
RESULTS: list[tuple[str, bool, str]] = []


def run(tool: str, *argv: str, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [PY, str(REPO / tool), *argv],
        capture_output=True, text=True, cwd=cwd, timeout=60,
    )


def check(name: str, ok: bool, detail: str = "") -> None:
    RESULTS.append((name, ok, detail))
    print(f"{'PASS' if ok else 'FAIL'}  {name}  {detail}")


def main() -> int:
    work = Path(tempfile.mkdtemp(prefix="smoke_"))
    print(f"workdir: {work}\n")

    # ---------------------------------------------------------- pickle
    pkl = work / "data.pkl"
    pkl.write_bytes(pickle.dumps({"a": [1, 2, 3], "t": ("x", 1.5), "s": {7}}))
    out_json = work / "data.json"
    r = run("pickle_convert/pickle_tool.py", "to-json", str(pkl), "-o", str(out_json))
    ok = r.returncode == 0 and out_json.exists()
    if ok:
        data = json.loads(out_json.read_text())
        ok = data.get("a") == [1, 2, 3] and data.get("t") == ["x", 1.5]
    check("pickle to-json", ok, r.stderr.strip()[:160])
    r = run("pickle_convert/pickle_tool.py", "inspect", str(pkl))
    check("pickle inspect", r.returncode == 0 and "dict" in r.stdout.lower(),
          (r.stdout + r.stderr).strip().splitlines()[0][:120] if (r.stdout + r.stderr).strip() else "")

    # ---------------------------------------------------------- bundle
    pkg = work / "minipkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "helper.py").write_text("VALUE = 41\n")
    (pkg / "app.py").write_text(
        "from .helper import VALUE\nprint('BUNDLE_RESULT', VALUE + 1)\n")
    merged = work / "minipkg_single.py"
    r = run("merge_split_python_pkg/python_bundle_tool.py", "merge", str(pkg), "-o", str(merged))
    ok = r.returncode == 0 and merged.exists()
    detail = r.stderr.strip()[:160]
    if ok:
        r2 = subprocess.run([PY, str(merged)], capture_output=True, text=True, timeout=30)
        ok = r2.returncode == 0 and "BUNDLE_RESULT 42" in r2.stdout
        detail = (r2.stdout + r2.stderr).strip()[:200]
    check("bundle merge+run", ok, detail)

    flat = work / "flat"
    flat.mkdir()
    (flat / "a.py").write_text("A = 1\n")
    (flat / "b.py").write_text("B = 2\n")
    concat = work / "all.py"
    r = run("merge_split_python_pkg/python_bundle_tool.py", "merge", str(flat),
            "--mode", "concat", "-o", str(concat))
    ok = r.returncode == 0 and concat.exists() and "# File:" in concat.read_text()
    restored = work / "restored"
    if ok:
        r = run("merge_split_python_pkg/python_bundle_tool.py", "split", str(concat), "-o", str(restored))
        ok = (r.returncode == 0
              and (restored / "a.py").exists() and "A = 1" in (restored / "a.py").read_text()
              and (restored / "b.py").exists() and "B = 2" in (restored / "b.py").read_text())
    check("concat merge+split roundtrip", ok, r.stderr.strip()[:160])

    # ---------------------------------------------------------- mover
    src = work / "mv"
    (src / "sub").mkdir(parents=True)
    (src / "sub" / "x.pdf").write_bytes(b"%PDF")
    (src / "y.pdf").write_bytes(b"%PDF")
    (src / "z.txt").write_text("hi")
    r = run("move_files_to_dir/file_mover_tool.py", "collect", "pdf", str(src), "-n")
    dry_ok = r.returncode == 0 and not (src / "pdf").exists()
    r = run("move_files_to_dir/file_mover_tool.py", "collect", "pdf", str(src))
    ok = dry_ok and r.returncode == 0 and (src / "pdf" / "x.pdf").exists() and (src / "pdf" / "y.pdf").exists()
    check("mover collect (dry-run+copy)", ok, r.stderr.strip()[:160])

    # ---------------------------------------------------------- normalize
    tricky = work / "tricky.py"
    tricky.write_text('s = "((( unbalanced in string"\nx = (1 + 2)\n')
    r = run("normalize_print_misc/python_normalize_tool.py", "brackets", str(tricky))
    check("normalize brackets token-based OK", r.returncode == 0,
          (r.stdout + r.stderr).strip()[:160])
    isn = work / "isn.py"
    isn.write_text("a = 1\nb = 2\nif a is not b:\n    pass\n")
    r = run("normalize_print_misc/python_normalize_tool.py", "is-not", str(isn))
    check("normalize is-not report", r.returncode == 0 and "isn.py" in r.stdout,
          r.stdout.strip()[:160])

    # ---------------------------------------------------------- log clean
    transcript = work / "t.txt"
    transcript.write_bytes(b"\x1b[31mRED\x1b[0m plain\x07\n")
    r = run("log_transcript_clean/log_clean_tool.py", "transcript", str(transcript), "--stdout")
    check("log transcript ANSI strip",
          r.returncode == 0 and "\x1b" not in r.stdout and "RED" in r.stdout,
          repr(r.stdout[:60]))
    hist = work / "hist"
    hist.write_text('ls\npwd\nls\ncd "`printf\ngit status\npwd\n')
    r = run("log_transcript_clean/log_clean_tool.py", "history", "--file", str(hist))
    cleaned = hist.read_text().splitlines() if hist.exists() else []
    check("log history dedup/de-junk",
          r.returncode == 0 and cleaned == ["ls", "pwd", "git status"],
          f"got {cleaned} err={r.stderr.strip()[:120]}")

    # ---------------------------------------------------------- finglish
    fa = work / "fa"
    fa.mkdir()
    (fa / "کتاب.txt").write_text("x")  # ketab -> ktab
    r = run("rename_translated_files/filename_translate_tool.py", "finglish", str(fa))
    check("finglish dry-run plan", r.returncode == 0 and "ktab" in r.stdout,
          r.stdout.strip()[:160])

    # ---------------------------------------------------------- qrcode (no deps -> graceful)
    r = run("qrcode_tools/qrcode_tool.py", "read", str(work / "nope.png"))
    try:
        import PIL  # noqa: F401
        check("qrcode read (Pillow present)", r.returncode in (0, 1) and "Traceback" not in r.stderr,
              r.stderr.strip()[:120])
    except ImportError:
        r2 = run("qrcode_tools/qrcode_tool.py", "read", str(tricky))  # existing file as "image"
        check("qrcode graceful missing-dep error",
              "pip install" in (r2.stderr + r2.stdout) and "Traceback" not in r2.stderr,
              (r2.stderr or r2.stdout).strip()[:160])

    # ---------------------------------------------------------- pypi (network, report-only)
    try:
        r = run("pypi_info_query/pypi_query_tool.py", "-t", "8", "info", "pip")
        print(f"INFO  pypi info pip -> rc={r.returncode}: {(r.stdout or r.stderr).strip()[:120]}")
    except Exception as exc:  # timeout etc.
        print(f"INFO  pypi info pip -> {exc} (network restricted, acceptable)")

    failed = [name for name, ok, _ in RESULTS if not ok]
    print(f"\n{len(RESULTS) - len(failed)}/{len(RESULTS)} checks passed; failed: {failed}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
