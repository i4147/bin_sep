"""Print a compact digest of each script: imports, defs, main-guard, hardcoded strings."""
from __future__ import annotations

import ast
import pathlib
import re
import sys


def digest(path: pathlib.Path) -> str:
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    out: list[str] = [f"\n### {path.parent.name}/{path.name} ({len(lines)} lines)"]
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        out.append(f"  SYNTAX-ERROR: {exc}")
        # show head
        out.append("  HEAD: " + " | ".join(l.strip() for l in lines[:12] if l.strip())[:400])
        return "\n".join(out)
    for node in tree.body:
        if isinstance(node, ast.Import):
            out.append("  import " + ", ".join(a.name for a in node.names))
        elif isinstance(node, ast.ImportFrom):
            out.append(f"  from {node.module} import " + ", ".join(a.name for a in node.names))
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            args = [a.arg + (f"={ast.unparse(a_default)}" if a_default else "") for a, a_default in _args(node)]
            doc = (ast.get_docstring(node) or "").splitlines()[0] if ast.get_docstring(node) else ""
            out.append(f"  def {node.name}({', '.join(args)})" + (f"  # {doc[:90]}" if doc else ""))
        elif isinstance(node, ast.ClassDef):
            out.append(f"  class {node.name} bases={[ast.unparse(b)[:40] for b in node.bases]}")
            for sub in node.body:
                if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    out.append(f"    def {sub.name}")
        elif isinstance(node, ast.Assign):
            try:
                code = ast.unparse(node).replace(chr(10), " ")[:160]
                out.append(f"  CONST: {code}")
            except Exception:
                pass
        elif isinstance(node, ast.If):
            if "main" in ast.unparse(node.test):
                body = ast.unparse(node).replace(chr(10), " ")[:500]
                out.append(f"  MAIN: {body}")
    # top-level stray statements (non def/import)
    strays = [ast.unparse(n).replace(chr(10), " ")[:100] for n in tree.body
              if isinstance(n, (ast.Expr, ast.Call)) or (isinstance(n, ast.Expr) and not isinstance(n.value, ast.Constant))]
    for s in strays[:4]:
        out.append(f"  STRAY: {s}")
    # argparse hints
    for m in re.finditer(r"add_argument\(([^)]{0,120})", text):
        out.append("  ARG: " + m.group(1).replace(chr(10), " ")[:130])
    # hardcoded paths/urls
    for m in sorted(set(re.findall(r"[\"'](/home/[^\"']+|/sdcard/[^\"']+|/data/[^\"']+|https?://[^\"']+)[\"']", text)))[:6]:
        out.append(f"  HARD: {m[:120]}")
    # subprocess commands
    for m in sorted(set(re.findall(r"[\"']((?:termux|clang|gcc|g\+\+|black|git|ffmpeg|espeak)[\w\-]*)[\"']", text)))[:6]:
        out.append(f"  CMD: {m}")
    return "\n".join(out)


def _args(fn: ast.FunctionDef) -> list[tuple[ast.arg, ast.expr | None]]:
    args = fn.args.args
    defaults = [None] * (len(args) - len(fn.args.defaults)) + list(fn.args.defaults)
    return list(zip(args, defaults))


def main() -> None:
    root = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path("/home/user/bin_sep")
    folders = sorted(p for p in root.iterdir() if p.is_dir() and p.name not in (".git", "arena"))
    if len(sys.argv) > 2:
        want = set(sys.argv[2:])
        folders = [f for f in folders if f.name in want]
    for folder in folders:
        print("\n" + "=" * 78 + f"\nFOLDER {folder.name}\n" + "=" * 78)
        for path in sorted(folder.glob("*.py")):
            print(digest(path))


if __name__ == "__main__":
    main()
