"""Validate consolidated scripts: compile + annotation audit + --help smoke test."""
from __future__ import annotations

import ast
import py_compile
import pathlib
import subprocess
import sys


def audit(path: pathlib.Path) -> list[str]:
    issues: list[str] = []
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.returns is None:
                issues.append(f"{path.name}:{node.lineno} {node.name} missing return annotation")
            for arg in [*node.args.posonlyargs, *node.args.args]:
                if arg.arg in ("self", "cls"):
                    continue
                if arg.annotation is None:
                    issues.append(f"{path.name}:{node.lineno} {node.name}({arg.arg}) missing annotation")
            if node.args.vararg and node.args.vararg.annotation is None:
                issues.append(f"{path.name}:{node.lineno} {node.name}(*{node.args.vararg.arg}) missing annotation")
            for kwa in node.args.kwonlyargs:
                if kwa.annotation is None:
                    issues.append(f"{path.name}:{node.lineno} {node.name}(kw {kwa.arg}) missing annotation")
            if node.args.kwarg and node.args.kwarg.annotation is None:
                issues.append(f"{path.name}:{node.lineno} {node.name}(**{node.args.kwarg.arg}) missing annotation")
    return issues


def main() -> int:
    root = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path("/home/user/bin_sep")
    files = sorted(p for p in root.glob("*/*.py") if p.name.startswith(("main_guard", "folder_archiver", "speech", "c_build", "package_exports", "syntax_triage", "clipboard", "comment_range", "csv_data", "duplicate", "line_endings", "encoding", "crypto", "env_secret", "python_imports", "file_viewer", "file_watch", "file_finder", "file_size", "folderize", "git_diff", "git_sync", "github", "html_asset", "html_to", "html_template", "image_triage", "terminal_image", "notebook", "license", "line_edit", "log_clean", "python_bundle", "file_mover", "python_normalize", "pickle", "pypi_", "qrcode_tool", "filename_")))
    if len(sys.argv) > 2:
        files = [pathlib.Path(x) for x in sys.argv[2:]]
    bad = 0
    for f in files:
        try:
            py_compile.compile(f, doraise=True)
        except Exception as exc:
            print(f"COMPILE-FAIL {f}: {exc}")
            bad += 1
            continue
        issues = audit(f)
        help_out = subprocess.run([sys.executable, str(f), "--help"], capture_output=True, text=True, timeout=30)
        status = "OK" if help_out.returncode == 0 else f"HELP-FAIL rc={help_out.returncode} err={help_out.stderr[:300]}"
        print(f"{f.parent.name}/{f.name}: compile OK, annotation-issues={len(issues)}, help={status}")
        for i in issues:
            print(f"   ! {i}")
        if issues or help_out.returncode != 0:
            bad += 1
    print(f"\n{len(files)} files checked, {bad} with problems")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
