"""Dump every .py file in every repo subfolder into one inventory text file."""
from __future__ import annotations

import hashlib
import pathlib


def main() -> None:
    root = pathlib.Path("/home/user/bin_sep")
    folders = sorted(p for p in root.iterdir() if p.is_dir() and p.name not in (".git", "arena"))
    out = pathlib.Path("/home/user/work/INVENTORY.txt")
    lines: list[str] = []
    for folder in folders:
        lines.append("\n" + "=" * 80 + f"\nFOLDER: {folder.name}\n" + "=" * 80)
        for path in sorted(folder.glob("*.py")):
            raw = path.read_bytes()
            text = raw.decode("utf-8", "replace")
            digest = hashlib.md5(raw).hexdigest()[:10]
            lines.append(f"\n----- {folder.name}/{path.name} md5={digest} bytes={len(raw)} lines={text.count(chr(10)) + 1} -----")
            lines.append(text)
    out.write_text("\n".join(lines), encoding="utf-8")
    print(f"wrote {out} size={out.stat().st_size}")
    for folder in folders:
        files = list(folder.glob("*.py"))
        total = sum(p.stat().st_size for p in files)
        print(f"{folder.name:32s} {len(files):2d} files {total:7d} bytes")


if __name__ == "__main__":
    main()
